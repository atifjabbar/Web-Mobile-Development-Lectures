// alert("Hello World");

// var a = 5;
// var b = 10;
// var c = a+b;
// alert(c);

// var a = 5;
// var b = 10;
// var c = a+b;
// console.log(c);

// var x = "ghous";
// var y = "ali";
// var z = y+x;
// alert(z);

// var f = 20;
// var g = "10";
// var h =  f+g;
// alert(h);

// var f = 20;
// var g = "2";
// var h =  f/g;
// alert(h);

// var a = 3;
// var b = 5;
// var c = 7;
// var d = (b - a) * c;
// alert(d);


// var a = 5;
// var b = ++a;
// alert(b);


var x = 10;
var y = x++ + ++x - x + x++ - ++x + x;
//      10  + 12  - 12+ 12  - 14  + 14
// 22
var z = alert(y);
